package ATC;
import java.io.File;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;


public class ATC {
	public static void main(String[] args) throws Exception  {
		
		

		
		String user="Enter username";
		String pass="Enter password";
		
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
		//Creating reference of Webdriver Interface
		WebDriver driver= new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");

		//Maximize Window
				driver.manage().window().maximize();
				
				
				//CLick on SIgnin
				driver.findElement(By.xpath("//a[@class='login']")).click();

				//Wait
				Thread.sleep(5000);

				//Enter Username
				WebElement userTextField = driver.findElement(By.xpath("//input[@name='email' and  @id ='email']"));
				userTextField.sendKeys(user);

				//Wait
				Thread.sleep(5000);

				//Enter Password
				WebElement PassTextField = driver.findElement(By.xpath("//input[@name='passwd' and  @id ='passwd']"));
				PassTextField.sendKeys(pass);
				
				//Click on signIN
				driver.findElement(By.xpath("//button[@name='SubmitLogin']")).click();
				
				Actions act = new Actions(driver);
	            act.sendKeys(Keys.PAGE_DOWN).build().perform(); //Page Down
	            System.out.println("Scroll down perfomed");
	            Thread.sleep(5000);
			// identify element
		    driver.findElement(By.linkText("My addresses")).click();
		    
		    Thread.sleep(5000);
		    
		    act.sendKeys(Keys.PAGE_DOWN).build().perform(); //Page Down
            System.out.println("Scroll down perfomed");
            Thread.sleep(5000);
	      
            //Add new address'
            driver.findElement(By.xpath("//a[@title='Add an address']")).click();
            Thread.sleep(5000);
            
            // adding new address details
            driver.findElement(By.id("firstname")).clear();
            driver.findElement(By.id("firstname")).sendKeys("Test");
            
            Thread.sleep(5000);
            driver.findElement(By.id("lastname")).clear();
            driver.findElement(By.id("lastname")).sendKeys("Data");
            
            
            Thread.sleep(5000);
            driver.findElement(By.id("company")).clear();
            driver.findElement(By.id("company")).sendKeys("ATC");
            
            Thread.sleep(5000);
            
            driver.findElement(By.id("address1")).sendKeys("#133 Swarnsree Enclave");
            Thread.sleep(5000);
            
            driver.findElement(By.id("address2")).sendKeys("9th cross road manjunath layout");
            Thread.sleep(5000);
            
            driver.findElement(By.id("city")).sendKeys("Bangalore");
            Thread.sleep(5000);
            
            Select state = new Select(driver.findElement(By.id("id_state")));
    		state.selectByVisibleText("Delaware");
    		
    		Thread.sleep(5000);
            
            driver.findElement(By.id("postcode")).sendKeys("00000");
            
            Thread.sleep(5000);
            driver.findElement(By.id("phone")).sendKeys("9823456789");
            
            Thread.sleep(5000);
            
            driver.findElement(By.id("phone_mobile")).sendKeys("9823452345");
            
            Thread.sleep(5000);
            driver.findElement(By.id("other")).sendKeys("not applicable");
            
            Thread.sleep(5000);
            driver.findElement(By.id("alias")).clear();
            driver.findElement(By.id("alias")).sendKeys("office");
            
            Thread.sleep(5000);
            
            driver.findElement(By.id("submitAddress")).click();
              System.out.print("Address saved successfully");
			      
			      //Return to home
			      driver.findElement(By.xpath("//a[@class='home']")).click();
			      
			      
			      // Mouse hover on womens and summer dress
			      Actions actions = new Actions(driver);
			        //Retrieve WebElement 'Womens' to perform mouse hover 
			      Thread.sleep(5000);
			     WebElement menuOption = driver.findElement(By.xpath("//a[@title='Women']"));
			     //Mouse hover menuOption 
			     actions.moveToElement(menuOption).perform();
				
			     //choosing submenu options
			     
			     Thread.sleep(7000);
			     
			     WebElement subMenuOption = driver.findElement(By.xpath("//a[@title='Summer Dresses']"));
			     actions.moveToElement(subMenuOption);
			     actions.click().build().perform();
			     
			     Thread.sleep(5000);
			     
			     act.sendKeys(Keys.PAGE_DOWN).build().perform(); //Page Down to change the grid to list view
			     driver.findElement(By.linkText("List")).click();
			     
			     // Click on the first item to view.
			     driver.findElement(By.xpath("//a[@class='products-block-image']")).click();
			     
			     //Increase the quantity to 5
			     driver.findElement(By.xpath("//input[@name='qty']")).clear();
			     driver.findElement(By.xpath("//input[@name='qty']")).sendKeys("5");
			     
			     //sizeto L
			     Select size = new Select(driver.findElement(By.id("group_1")));
		    		size.selectByVisibleText("L");
		    		
		    		//Choosecolor
		    		driver.findElement(By.xpath("//a[@title='Black']")).click();
		    		
		    		//Add to cart
		    		driver.findElement(By.xpath("//span[text()='Add to cart']")).click();
		    		
		    		//continue shopping
		    		driver.findElement(By.xpath("//span[@class='continue btn btn-default button exclusive-medium']/span/i")).click();
		    		
		    		//repeat for other 2dresses
		    		driver.findElement(By.linkText("Summer Dresses")).click();
		    		
		   driver.findElement(By.xpath("//li[@class='ajax_block_product last-line last-item-of-tablet-line last-mobile-line col-xs-12']/div/div/div/div/a/img")).click();
				     
				     //Increase the quantity to 5
				     driver.findElement(By.xpath("//input[@name='qty']")).clear();
				     driver.findElement(By.xpath("//input[@name='qty']")).sendKeys("5");
				     
				     //sizeto L
				     Select size1 = new Select(driver.findElement(By.id("group_1")));
			    		size1.selectByVisibleText("L");
			    		
			    		//Add to cart
			    		driver.findElement(By.xpath("//span[text()='Add to cart']")).click();
			    		
			    		//continue shopping
			    		driver.findElement(By.xpath("//span[@class='continue btn btn-default button exclusive-medium']/span/i")).click();
			    		
			    		//repeat for other 2dresses
			    		driver.findElement(By.linkText("Summer Dresses")).click();
			    		
			    		driver.findElement(By.xpath("//li[@class='ajax_block_product last-in-line last-line first-item-of-tablet-line last-item-of-mobile-line last-mobile-line col-xs-12']/div/div/div/div/a/img")).click();
					     
					     //Increase the quantity to 5
					     driver.findElement(By.xpath("//input[@name='qty']")).clear();
					     driver.findElement(By.xpath("//input[@name='qty']")).sendKeys("5");
					     
					     //size to L
					     Select size2 = new Select(driver.findElement(By.id("group_1")));
				    		size2.selectByVisibleText("L");
				    		
				    		//Add to cart
				    		driver.findElement(By.xpath("//span[text()='Add to cart']")).click();
				    		
				    		driver.findElement(By.xpath("//a[@class='btn btn-default button button-medium']")).click();
				    		
				    		driver.findElement(By.xpath("//span[text()='Proceed to checkout']")).click();
				    		
				    		driver.findElement(By.xpath("//span[text()='Proceed to checkout']")).click();
				    		
				    		//agree to tc
				    		driver.findElement(By.id("cgv")).click();
				    		driver.findElement(By.xpath("//span[text()='Proceed to checkout']")).click();
				    		
				    		//payment
				    		driver.findElement(By.xpath("//a[@class='bankwire']")).click();
				    		
				    		//confirm order
				    		driver.findElement(By.xpath("//span[text()='I confirm my order']")).click();
				    		
				    		//go to customer account
				    		driver.findElement(By.xpath("//a[@title='View my customer account']")).click();
				    		
				    		//order history
				    		driver.findElement(By.xpath("//a[@title='Orders']")).click();
				    		
				    		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				            
				            //Copy the file to a location and use try catch block to handle exception
				            try {
				                Files.copy(screenshot, new File("C:\\orderScreenshot.png"));
				            } catch (IOException e) {
				                System.out.println(e.getMessage());
				            }
				    		
				            
				            //logging out from application
			    		
				            driver.findElement(By.xpath("//a[@title='Log me out']")).click();
			    		driver.quit();
	}
}